Three.js only supports quads, which means these models have to be converted.
Use the included Python file (by reddit.com/u/mrspeaker) to convert.

fixQuads.py: https://gist.github.com/mrspeaker/f9bae3c3765ee0d73686